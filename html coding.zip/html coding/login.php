<?php
$U=$_GET["Name"];
$V=$_GET["Pass"];
$W=$_GET["Roll"];
echo $U;
echo $V;
echo $W;
?>